package com.homedepot.order.data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderDataServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderDataServiceApplication.class, args);
	}

}
